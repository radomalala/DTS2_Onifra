import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Task, TaskStats } from '../models/task';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  private tasks: Task[] = [
    {
      id: 1,
      title: 'Terminer le TD Angular',
      description: 'Compléter tous les exercices du TD',
      status: 'in-progress',
      priority: 'high',
      createdAt: new Date('2024-11-01'),
      dueDate: new Date('2024-11-10')
    },
    {
      id: 2,
      title: 'Réviser TypeScript',
      description: 'Revoir les concepts avancés',
      status: 'todo',
      priority: 'medium',
      createdAt: new Date('2024-11-02')
    },
    {
      id: 3,
      title: 'Préparer présentation',
      description: 'Créer les slides pour le cours',
      status: 'done',
      priority: 'high',
      createdAt: new Date('2024-10-28'),
      dueDate: new Date('2024-11-05')
    }
  ];

  private tasksSubject = new BehaviorSubject<Task[]>(this.tasks);
  public tasks$ = this.tasksSubject.asObservable();

  constructor() { }

  getTasks(): Observable<Task[]> {
    return this.tasks$;
  }

  getTaskById(id: number): Task | undefined {
    return this.tasks.find(task => task.id === id);
  }

  addTask(task: Omit<Task, 'id' | 'createdAt'>): void {
    const newTask: Task = {
      ...task,
      id: this.generateId(),
      createdAt: new Date()
    };
    this.tasks.push(newTask);
    this.tasksSubject.next(this.tasks);
  }

  updateTask(id: number, updatedTask: Partial<Task>): void {
    const index = this.tasks.findIndex(task => task.id === id);
    if (index !== -1) {
      this.tasks[index] = { ...this.tasks[index], ...updatedTask };
      this.tasksSubject.next(this.tasks);
    }
  }

  deleteTask(id: number): void {
    this.tasks = this.tasks.filter(task => task.id !== id);
    this.tasksSubject.next(this.tasks);
  }

  getStats(): TaskStats {
    return {
      total: this.tasks.length,
      todo: this.tasks.filter(t => t.status === 'todo').length,
      inProgress: this.tasks.filter(t => t.status === 'in-progress').length,
      done: this.tasks.filter(t => t.status === 'done').length
    };
  }

  private generateId(): number {
    return this.tasks.length > 0 
      ? Math.max(...this.tasks.map(t => t.id)) + 1 
      : 1;
  }
}
