import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TaskService } from '../../services/task';

@Component({
  selector: 'app-task-form',
  templateUrl: './task-form.html',
  styleUrls: ['./task-form.css'],
  imports: [FormsModule]
})
export class TaskFormComponent {
  task = {
    title: '',
    description: '',
    status: 'todo' as 'todo' | 'in-progress' | 'done',
    priority: 'medium' as 'low' | 'medium' | 'high',
    dueDate: undefined as Date | undefined
  };

  constructor(private taskService: TaskService) { }

  onSubmit(): void {
    if (this.task.title.trim()) {
      this.taskService.addTask(this.task);
      this.resetForm();
    }
  }

  resetForm(): void {
    this.task = {
      title: '',
      description: '',
      status: 'todo',
      priority: 'medium',
      dueDate: undefined
    };
  }
}
