import { Component, OnInit } from '@angular/core';
import { TaskService } from '../../services/task';
import { TaskStats } from '../../models/task';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css'],
  imports: []
})
export class DashboardComponent implements OnInit {
  stats: TaskStats = { total: 0, todo: 0, inProgress: 0, done: 0 };

  constructor(private taskService: TaskService) { }

  ngOnInit(): void {
    this.taskService.getTasks().subscribe(() => {
      this.stats = this.taskService.getStats();
    });
  }

  getCompletionPercentage(): number {
    return this.stats.total > 0 
      ? Math.round((this.stats.done / this.stats.total) * 100) 
      : 0;
  }
}
