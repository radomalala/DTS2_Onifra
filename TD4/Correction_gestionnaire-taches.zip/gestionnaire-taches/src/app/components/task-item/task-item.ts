import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule, DatePipe, NgIf } from '@angular/common';
import { Task } from '../../models/task';

@Component({
  selector: 'app-task-item',
  templateUrl: './task-item.html',
  styleUrls: ['./task-item.css'],
  imports: [
    DatePipe,
    NgIf,
    CommonModule
  ]
})
export class TaskItemComponent {
  @Input() task!: Task;
  @Output() statusChange = new EventEmitter<{ id: number, status: Task['status'] }>();
  @Output() delete = new EventEmitter<number>();

  getStatusLabel(status: string): string {
    const labels: any = {
      'todo': 'À faire',
      'in-progress': 'En cours',
      'done': 'Terminée'
    };
    return labels[status] || status;
  }

  getPriorityLabel(priority: string): string {
    const labels: any = {
      'low': 'Basse',
      'medium': 'Moyenne',
      'high': 'Haute'
    };
    return labels[priority] || priority;
  }

  onStatusChange(newStatus: Task['status']): void {
    this.statusChange.emit({ id: this.task.id, status: newStatus });
  }

  onDelete(): void {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette tâche ?')) {
      this.delete.emit(this.task.id);
    }
  }
}
